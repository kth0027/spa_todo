import React from "react";
import "./App.css";

function App() {
  const userName = "alex";
  return <h1>Hello {userName}!</h1>;
}

export default App;
