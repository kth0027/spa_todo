import React from "react";
import "./App.css";

function App() {
  return (
    <div>
      <p>
        Edit <code>src/App.js</code> and save to reload.
      </p>
      <a href="https://reactjs.org">Learn React</a>
    </div>
  );
}

export default App;
