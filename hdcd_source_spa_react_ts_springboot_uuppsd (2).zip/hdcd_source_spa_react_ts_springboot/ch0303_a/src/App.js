import React, { Component } from "react";
import "./App.css";

class App extends Component {
  render() {
    const userName = "alex";
    return <h1>Hello {userName}!</h1>;
  }
}

export default App;
