import React from "react";
import "./App.css";

function App() {
  return (
      <p>
        Edit <code>src/App.js</code> and save to reload.
      </p>
      <a href="https://reactjs.org">Learn React</a>
  );
}

export default App;
